sudo insmod  /lib/modules/4.12.0+/kernel/lib/lz4/lz4_compress.ko
