#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <math.h>

#define FILE_MB_SIZE 400

#define RANDOM(__min__, __max__) ((int)(((double)((rand()<<15) | rand())) / ((RAND_MAX<<15 | RAND_MAX) + 1) * (((__max__) + 1) - (__min__))) + (__min__))

char str[1024*1024*FILE_MB_SIZE];

char sentence[10][70] = {"ekfmwkdjekfiejdkwmdjskdmwjdkwmlllsmdkwmdksmwkdmsjfiwdjjwkdmsjdkwkdmwkd",
			"jjjsleoieieifjjdqqqpqfdkdkvmvmmmvmvwweeeeeofopdjfjjapapapappppafqwwwww",
			"dkkkwwpppqwoeqwpwopqwjopjfqwopjfqwjfwqjqwfjqfwjfqwjfjjjjqfwjwqjwqwqwqw",
			"dklfjcjjcncndlkvzzxnxzcmzxcmizjxcioczxjiozxcjioczxjioczxjiozcxjiozxcji",
			"wqiwqeiuowqeiuoweqiouwqeiouweqiouweqiouwqeiwiwiwiiiiiiiiiiiiiiiiiiiiii",
			"wqqiqqqqqqzzzaakldkdkdkdqwkdqwkdwjiodjwiojwiowjdiowjdddddoqoqooqoqoqqq",
			"dksltlqkdlrekflsprkspeifnekfmwkwndnegjvlakemfjkwjelfkwemakwjdkwmlakenf",
			"dkrorkxspwlswkdfkelwpqdkrhtrltvkekdldjrwlskwekehfkwmsjrlwkakekwdkdwmwk",
			"enroaksejgkwkwkwkdkdfenenfqwkwkmwkwndjwbqhqwudjwkcmwkwjduwhxjwjwbqhqjs",
			"wqlqleodijejenebwbwdhwjkfnwnbwjwjdiqoiqksiwivjwhxuhwudknwnfejekwwkwdmw"};


char val[36] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','0','1','2','3','4','5','6','7','8','9'};
int main()
{

	FILE *fp = fopen("firstTest_400.txt", "w");

	for( int i=0;i<1024*1024*FILE_MB_SIZE;){
		int idx = rand() % 36;
		for( int j =0; j<70; j++, i++)
		{
			str[i] = sentence[rand()%5][j];
			if( i >= 1024*1024 *FILE_MB_SIZE) break;
		}
		//printf("index: %d\n", idx);
		str[i] = val[idx];
	}

	fwrite(str, sizeof(str), 1, fp);

	fclose(fp);	


	return 0;
}
