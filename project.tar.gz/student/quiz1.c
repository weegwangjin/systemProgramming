#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


int main() {
	int fd;
	char *buf2;
	char *test = (char*)malloc(4096);
	int fd_test;

	if((fd_test = open("./secondTest_400.txt", O_RDWR)) < 0 ) {
		perror("open error");
		exit(1);

	}

	if((fd = open("/dev/sbulla", O_RDWR)) < 0 ) {
		perror ("open error");
		exit(1);
	}	
	
	clock_t start = clock();

	while((read(fd_test, test, 4096)) > 0) {
		if(write(fd, test, 4096) < 0) {
			perror("write error");
			exit(1);
		}	
	}
	
	clock_t end = clock();

	printf("compressed time : %lf\n", (double)(end-start)/CLOCKS_PER_SEC);
	
	
        fsync(fd);
        //close(fd);
	close(fd_test);
/*
	if((fd = open("/dev/sbulla",O_RDONLY)) < 0) {
	    perror("open error");
		exit(1);
	}
*/    	
	printf("Reading start\n");

	start = clock();

	buf2 = (char*)malloc(4096);
	int cnt = 0;
	while(read(fd, buf2, 4096) > 0) {
		cnt++;
		//printf("reading compressed data.... %d\n",cnt);
		if ( cnt > 1024*25*4) break;
		
	}
	
	end = clock();

	printf("decompressed time : %lf\n", (double) (end-start)/CLOCKS_PER_SEC);
	close(fd);

	return 0;
}
