make

sleep 1

sudo ./sbull_unload

sleep 1

sudo ./sbull_load
