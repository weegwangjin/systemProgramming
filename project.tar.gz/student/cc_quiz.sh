sudo rm quiz1
sleep 1
sudo make quiz1
